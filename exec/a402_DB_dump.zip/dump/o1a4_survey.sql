CREATE DATABASE  IF NOT EXISTS `o1a4` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `o1a4`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: j7a402.p.ssafy.io    Database: o1a4
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `survey` (
  `user_no` int NOT NULL,
  `reply_list` json NOT NULL,
  PRIMARY KEY (`user_no`),
  CONSTRAINT `survey_user_no_c8c4ece0_fk_user_user_no` FOREIGN KEY (`user_no`) REFERENCES `user` (`user_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (101,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\"]'),(102,'[\"N\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\"]'),(103,'[\"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\"]'),(104,'[\"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\"]'),(105,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(106,'[\"Y\", \"Y\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\"]'),(107,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(108,'[\"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"Y\"]'),(109,'[\"Y\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\"]'),(110,'[\"N\", \"Y\", false, false, false, false, false, false, false, false]'),(111,'[\"N\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\"]'),(112,'[\"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\"]'),(113,'[\"Y\", \"Y\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"Y\"]'),(114,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"N\"]'),(115,'[\"Y\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"Y\", \"N\"]'),(116,'[\"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"N\"]'),(117,'[\"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\"]'),(118,'[\"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\"]'),(119,'[\"Y\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(120,'[\"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"N\"]'),(121,'[\"N\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"N\"]'),(122,'[\"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\"]'),(123,'[\"Y\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(124,'[\"N\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\"]'),(125,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\"]'),(126,'[\"Y\", \"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(127,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(128,'[\"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(129,'[\"Y\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"N\"]'),(130,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(131,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"N\", \"Y\"]'),(132,'[\"N\", \"N\", \"Y\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\"]'),(133,'[\"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(134,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(135,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(136,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\"]'),(137,'[\"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\"]'),(138,'[\"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\"]'),(139,'[\"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"N\"]'),(140,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(141,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(142,'[\"Y\", \"Y\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"Y\"]'),(143,'[\"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"Y\"]'),(144,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"Y\", \"N\", \"N\", \"N\", \"N\"]'),(145,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\"]'),(146,'[\"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\", \"N\"]'),(147,'[\"Y\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\"]'),(148,'[\"N\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(149,'[\"N\", \"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"N\", \"N\", \"Y\"]'),(150,'[\"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"Y\"]'),(151,'[\"N\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"N\", \"N\", \"Y\"]'),(152,'[\"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"N\", \"Y\", \"Y\"]'),(153,'[\"Y\", \"Y\", \"Y\", \"Y\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(154,'[\"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"N\", \"Y\", \"Y\"]'),(155,'[\"Y\", \"N\", \"N\", \"N\", \"Y\", \"N\", \"Y\", \"Y\", \"Y\", \"Y\"]'),(156,'[\"N\", \"N\", \"N\", \"N\", \"Y\", \"Y\", \"N\", \"Y\", \"N\", \"Y\"]');
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-06 22:54:55
