CREATE DATABASE  IF NOT EXISTS `o1a4` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_bin */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `o1a4`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: j7a402.p.ssafy.io    Database: o1a4
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb3_bin NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb3_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add user',1,'add_user'),(2,'Can change user',1,'change_user'),(3,'Can delete user',1,'delete_user'),(4,'Can view user',1,'view_user'),(5,'Can add user_kind_code',2,'add_user_kind_code'),(6,'Can change user_kind_code',2,'change_user_kind_code'),(7,'Can delete user_kind_code',2,'delete_user_kind_code'),(8,'Can view user_kind_code',2,'view_user_kind_code'),(9,'Can add survey',3,'add_survey'),(10,'Can change survey',3,'change_survey'),(11,'Can delete survey',3,'delete_survey'),(12,'Can view survey',3,'view_survey'),(13,'Can add alcohol',4,'add_alcohol'),(14,'Can change alcohol',4,'change_alcohol'),(15,'Can delete alcohol',4,'delete_alcohol'),(16,'Can view alcohol',4,'view_alcohol'),(17,'Can add alcohol_code',5,'add_alcohol_code'),(18,'Can change alcohol_code',5,'change_alcohol_code'),(19,'Can delete alcohol_code',5,'delete_alcohol_code'),(20,'Can view alcohol_code',5,'view_alcohol_code'),(21,'Can add region_code',6,'add_region_code'),(22,'Can change region_code',6,'change_region_code'),(23,'Can delete region_code',6,'delete_region_code'),(24,'Can view region_code',6,'view_region_code'),(25,'Can add alcohol_recommend',7,'add_alcohol_recommend'),(26,'Can change alcohol_recommend',7,'change_alcohol_recommend'),(27,'Can delete alcohol_recommend',7,'delete_alcohol_recommend'),(28,'Can view alcohol_recommend',7,'view_alcohol_recommend'),(29,'Can add alcohol_score4',8,'add_alcohol_score4'),(30,'Can change alcohol_score4',8,'change_alcohol_score4'),(31,'Can delete alcohol_score4',8,'delete_alcohol_score4'),(32,'Can view alcohol_score4',8,'view_alcohol_score4'),(33,'Can add alcohol_score3',9,'add_alcohol_score3'),(34,'Can change alcohol_score3',9,'change_alcohol_score3'),(35,'Can delete alcohol_score3',9,'delete_alcohol_score3'),(36,'Can view alcohol_score3',9,'view_alcohol_score3'),(37,'Can add alcohol_score2',10,'add_alcohol_score2'),(38,'Can change alcohol_score2',10,'change_alcohol_score2'),(39,'Can delete alcohol_score2',10,'delete_alcohol_score2'),(40,'Can view alcohol_score2',10,'view_alcohol_score2'),(41,'Can add alcohol_score1',11,'add_alcohol_score1'),(42,'Can change alcohol_score1',11,'change_alcohol_score1'),(43,'Can delete alcohol_score1',11,'delete_alcohol_score1'),(44,'Can view alcohol_score1',11,'view_alcohol_score1'),(45,'Can add ranking',12,'add_ranking'),(46,'Can change ranking',12,'change_ranking'),(47,'Can delete ranking',12,'delete_ranking'),(48,'Can view ranking',12,'view_ranking'),(49,'Can add review',13,'add_review'),(50,'Can change review',13,'change_review'),(51,'Can delete review',13,'delete_review'),(52,'Can view review',13,'view_review'),(53,'Can add user_group_figure',14,'add_user_group_figure'),(54,'Can change user_group_figure',14,'change_user_group_figure'),(55,'Can delete user_group_figure',14,'delete_user_group_figure'),(56,'Can view user_group_figure',14,'view_user_group_figure'),(57,'Can add user_alcohol',15,'add_user_alcohol'),(58,'Can change user_alcohol',15,'change_user_alcohol'),(59,'Can delete user_alcohol',15,'delete_user_alcohol'),(60,'Can view user_alcohol',15,'view_user_alcohol'),(61,'Can add alcohol_like',16,'add_alcohol_like'),(62,'Can change alcohol_like',16,'change_alcohol_like'),(63,'Can delete alcohol_like',16,'delete_alcohol_like'),(64,'Can view alcohol_like',16,'view_alcohol_like'),(65,'Can add recommend_mf',17,'add_recommend_mf'),(66,'Can change recommend_mf',17,'change_recommend_mf'),(67,'Can delete recommend_mf',17,'delete_recommend_mf'),(68,'Can view recommend_mf',17,'view_recommend_mf'),(69,'Can add log entry',18,'add_logentry'),(70,'Can change log entry',18,'change_logentry'),(71,'Can delete log entry',18,'delete_logentry'),(72,'Can view log entry',18,'view_logentry'),(73,'Can add permission',19,'add_permission'),(74,'Can change permission',19,'change_permission'),(75,'Can delete permission',19,'delete_permission'),(76,'Can view permission',19,'view_permission'),(77,'Can add group',20,'add_group'),(78,'Can change group',20,'change_group'),(79,'Can delete group',20,'delete_group'),(80,'Can view group',20,'view_group'),(81,'Can add user',21,'add_user'),(82,'Can change user',21,'change_user'),(83,'Can delete user',21,'delete_user'),(84,'Can view user',21,'view_user'),(85,'Can add content type',22,'add_contenttype'),(86,'Can change content type',22,'change_contenttype'),(87,'Can delete content type',22,'delete_contenttype'),(88,'Can view content type',22,'view_contenttype'),(89,'Can add session',23,'add_session'),(90,'Can change session',23,'change_session'),(91,'Can delete session',23,'delete_session'),(92,'Can view session',23,'view_session');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-06 22:54:54
